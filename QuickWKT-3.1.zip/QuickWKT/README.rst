QuickWKT Qgis Plugin
====================

This Qgis Plugin makes it possible to show features in QGIS using WKT

This plugin is supposed to be installed via the plugin manager of QGIS


Code: https://github.com/elpaso/quickwkt

Plugin: http://plugins.qgis.org/plugins/QuickWKT/


Original Author: Alessandro Pasotti

Contributing Autors:

* Richard Duivenvoorde
* Ryan Lewis


See metadata.txt for changelog